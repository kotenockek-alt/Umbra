-- ============================================================================
--  UMBRA MESSENGER — ЧИСТАЯ установка схемы (можно запускать повторно)
--  Выполнить ЦЕЛИКОМ в Supabase → SQL Editor → Run.
-- ============================================================================

-- 0. Полная очистка прошлых попыток (данных нет — терять нечего)
drop schema if exists public cascade;
create schema public;
grant all on schema public to postgres, anon, authenticated, service_role;

drop policy if exists "storage public read" on storage.objects;
drop policy if exists "storage auth write"  on storage.objects;


-- 1. PROFILES
create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  name        text not null default 'Безымянный',
  username    text not null,
  avatar_url  text,
  created_at  timestamptz not null default now(),
  constraint username_format check (username ~ '^[A-Za-zА-Яа-яЁё0-9]+$'),
  constraint username_length check (char_length(username) between 3 and 32)
);
create unique index profiles_username_unique on public.profiles (lower(username));

-- 2. USER_ROLES
create table public.user_roles (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles(id) on delete cascade,
  name        text not null,
  avatar_url  text,
  created_at  timestamptz not null default now()
);
create index user_roles_owner_idx on public.user_roles(owner_id);

-- 3. CONTACTS
create table public.contacts (
  id           uuid primary key default gen_random_uuid(),
  owner_id     uuid not null references public.profiles(id) on delete cascade,
  contact_id   uuid not null references public.profiles(id) on delete cascade,
  custom_name  text,
  created_at   timestamptz not null default now(),
  unique (owner_id, contact_id)
);
create index contacts_owner_idx on public.contacts(owner_id);

-- 4. CHATS
create table public.chats (
  id              uuid primary key default gen_random_uuid(),
  title           text not null,
  avatar_url      text,
  background_url  text,
  is_group        boolean not null default true,
  creator_id      uuid not null references public.profiles(id) on delete cascade,
  created_at      timestamptz not null default now()
);
create index chats_creator_idx on public.chats(creator_id);

create type member_role as enum ('creator', 'admin', 'member');

-- 5. CHAT_MEMBERS
create table public.chat_members (
  id               uuid primary key default gen_random_uuid(),
  chat_id          uuid not null references public.chats(id) on delete cascade,
  user_id          uuid not null references public.profiles(id) on delete cascade,
  system_role      member_role not null default 'member',
  selected_role_id uuid references public.user_roles(id) on delete set null,
  joined_at        timestamptz not null default now(),
  unique (chat_id, user_id)
);
create index chat_members_chat_idx on public.chat_members(chat_id);
create index chat_members_user_idx on public.chat_members(user_id);

create type message_kind as enum ('text', 'image', 'video');

-- 6. MESSAGES
create table public.messages (
  id          uuid primary key default gen_random_uuid(),
  chat_id     uuid not null references public.chats(id) on delete cascade,
  sender_id   uuid not null references public.profiles(id) on delete cascade,
  role_id     uuid references public.user_roles(id) on delete set null,
  kind        message_kind not null default 'text',
  body        text,
  media_url   text,
  created_at  timestamptz not null default now()
);
create index messages_chat_idx on public.messages(chat_id, created_at);

-- 7. EVENTS
create table public.events (
  id          uuid primary key default gen_random_uuid(),
  chat_id     uuid not null references public.chats(id) on delete cascade,
  text        text not null,
  created_at  timestamptz not null default now()
);
create index events_chat_idx on public.events(chat_id, created_at);

-- ХЕЛПЕРЫ
create or replace function public.is_member(p_chat uuid)
returns boolean language sql security definer stable as $$
  select exists(select 1 from public.chat_members
    where chat_id = p_chat and user_id = auth.uid());
$$;

create or replace function public.my_role(p_chat uuid)
returns member_role language sql security definer stable as $$
  select system_role from public.chat_members
  where chat_id = p_chat and user_id = auth.uid();
$$;

-- RLS
alter table public.profiles      enable row level security;
alter table public.user_roles    enable row level security;
alter table public.contacts      enable row level security;
alter table public.chats         enable row level security;
alter table public.chat_members  enable row level security;
alter table public.messages      enable row level security;
alter table public.events        enable row level security;

create policy profiles_read   on public.profiles for select using (true);
create policy profiles_insert on public.profiles for insert with check (auth.uid() = id);
create policy profiles_update on public.profiles for update using (auth.uid() = id);

create policy roles_read on public.user_roles for select using (true);
create policy roles_all  on public.user_roles for all
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy contacts_all on public.contacts for all
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy chats_read on public.chats for select using (public.is_member(id));
create policy chats_insert on public.chats for insert with check (creator_id = auth.uid());
create policy chats_update on public.chats for update
  using (public.my_role(id) in ('creator','admin'));

create or replace function public.guard_chat_background()
returns trigger language plpgsql security definer as $$
begin
  if new.background_url is distinct from old.background_url
     and old.creator_id <> auth.uid() then
    raise exception 'Фон чата может менять только создатель';
  end if;
  return new;
end; $$;
create trigger trg_guard_background
  before update on public.chats
  for each row execute function public.guard_chat_background();

create policy members_read on public.chat_members for select using (public.is_member(chat_id));
create policy members_insert on public.chat_members for insert
  with check (user_id = auth.uid() or public.my_role(chat_id) in ('creator','admin'));
create policy members_update on public.chat_members for update
  using (user_id = auth.uid() or public.my_role(chat_id) in ('creator','admin'));
create policy members_delete on public.chat_members for delete
  using (user_id = auth.uid() or public.my_role(chat_id) in ('creator','admin'));

create policy messages_read on public.messages for select using (public.is_member(chat_id));
create policy messages_insert on public.messages for insert
  with check (sender_id = auth.uid() and public.is_member(chat_id));
create policy messages_delete on public.messages for delete
  using (sender_id = auth.uid() or public.my_role(chat_id) in ('creator','admin'));

create policy events_read on public.events for select using (public.is_member(chat_id));
create policy events_insert on public.events for insert
  with check (public.my_role(chat_id) in ('creator','admin'));

-- ТРИГГЕР: создатель чата автоматически становится участником
create or replace function public.add_creator_as_member()
returns trigger language plpgsql security definer as $$
begin
  insert into public.chat_members (chat_id, user_id, system_role)
  values (new.id, new.creator_id, 'creator');
  return new;
end; $$;
create trigger trg_add_creator
  after insert on public.chats
  for each row execute function public.add_creator_as_member();

-- STORAGE
insert into storage.buckets (id, name, public)
values ('avatars','avatars',true), ('backgrounds','backgrounds',true), ('media','media',true)
on conflict (id) do nothing;

create policy "storage public read"  on storage.objects for select using (true);
create policy "storage auth write"   on storage.objects for insert
  to authenticated with check (true);
