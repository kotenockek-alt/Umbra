'use client';

import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase/client';
import type { Chat } from '@/types/db';

export function useChats(userId: string | null) {
  const [chats, setChats] = useState<Chat[]>([]);
  const [query, setQuery] = useState('');

  const load = useCallback(async () => {
    if (!userId) return;
    // чаты, где пользователь — участник
    const { data: members } = await supabase
      .from('chat_members').select('chat_id').eq('user_id', userId);
    const ids = (members ?? []).map((m) => m.chat_id);
    if (!ids.length) { setChats([]); return; }

    const { data } = await supabase
      .from('chats').select('*').in('id', ids)
      .order('created_at', { ascending: false });
    let list = (data as Chat[]) ?? [];

    // подтягиваем время последнего сообщения для каждого чата
    const { data: msgs } = await supabase
      .from('messages').select('chat_id, created_at')
      .in('chat_id', ids).order('created_at', { ascending: false });
    const lastByChat: Record<string, string> = {};
    (msgs ?? []).forEach((m: any) => {
      if (!lastByChat[m.chat_id]) lastByChat[m.chat_id] = m.created_at;
    });
    list = list.map((c) => ({ ...c, last_message_at: lastByChat[c.id] ?? null }));
    // сортируем: чаты с недавними сообщениями выше
    list.sort((a, b) => (b.last_message_at ?? b.created_at).localeCompare(a.last_message_at ?? a.created_at));

    setChats(list);
  }, [userId]);

  useEffect(() => { load(); }, [load]);

  // поиск по названию
  const filtered = chats.filter((c) =>
    c.title.toLowerCase().includes(query.toLowerCase()));

  return { chats: filtered, query, setQuery, reload: load };
}
